# Some operations:

INFOR/END\_INFOR
INIF/END\_INIF
OUTFOR/END\_OUTFOR
OUTIF/END\_OUTIF

gSUM,gPROD,gCOND
gNz,gNa
gI,gD
gGI

REG-vmz

# Importing values, vectors, sets of values and vectors

sets (e.g., D2Q9, D3Q19, D3Q27)

value
setvalue
vector
setvector
